================================================================================
PROGRESSIVE WEB APP (PWA) - SEKOLAH ULIL ALBAB
Package Download
================================================================================

TENTANG PACKAGE INI:
Package ini berisi file-file PWA yang dapat Anda install di perangkat Anda.

ISI PACKAGE:
- pwa.js              : PWA manager
- sw.js               : Service worker
- manifest.json       : Web app manifest
- pwa-styles.css      : Styling PWA
- icons/              : Icon aplikasi (8 ukuran)
- README.txt          : File ini
- CARA_INSTALL.txt    : Panduan instalasi

CARA MENGGUNAKAN:
1. Extract file ZIP ini
2. Buka file CARA_INSTALL.txt untuk panduan lengkap
3. Atau kunjungi: http://localhost:8080//pwa/install

SYSTEM REQUIREMENTS:
- Browser modern (Chrome, Firefox, Safari, Edge)
- Koneksi internet (untuk instalasi pertama)
- HTTPS (untuk production)

SUPPORT:
Website: http://localhost:8080/
Install Guide: http://localhost:8080//pwa/install

================================================================================
Made with ❤️ for Sekolah Ulil Albab
================================================================================